document.getElementById("bookingForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const contact = document.getElementById("contact").value;
  const email = document.getElementById("email").value;
  const numberofpeople = document.getElementById("numberofpeople").value;

  const queryParams = new URLSearchParams({
    contact,
    email,
    numberofpeople
  }).toString();

  window.location.href = `printTicket.html?${queryParams}`;
});