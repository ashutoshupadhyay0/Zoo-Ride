const Ticket = require("../models/ticket")

async function handleDeleteTicket(req, res) {
    await Ticket.findByIdandDelete(req.params.contact)
    res.json({status: 'Delete'})
}

async function handleCreateTicket(req , res ) {
    const body = req.body;
    if (
        !body || !body.contact || !body.people || !body.email 
    ) {
        return res.status(400).json({ msg: "All fields required" });
    }

    const result = await Ticket.create({
        contact: body.contact,
        people: body.people,
        email: body.email,
    });

    console.log('result', result);
    return res.status(201).json({msg: "success" , id: result._id})
}

module.exports = {
    handleCreateTicket , handleDeleteTicket ,
}