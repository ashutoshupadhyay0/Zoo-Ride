const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    contact: {
        type: String,
        required: true,
    },
    people: {
        type: Number,
        required: true,
    },
    email: {
        type: String,
        required: true,
    }
},
    { timestamps: true }
);

const Ticket = mongoose.model('ticket', userSchema);
