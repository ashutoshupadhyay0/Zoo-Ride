const express = require("express");
const { handleCreateTicket , handleDeleteTicket } = require('../controllers/ticket');

const router = express.Router();

router
    .post(handleCreateTicket);


router
    .delete(handleDeleteTicket)


    
module.exports = router;